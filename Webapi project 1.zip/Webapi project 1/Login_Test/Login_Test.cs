using Couchbase;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using System;
using System.Threading.Tasks;
using Webapi_project_1.Controllers;
using Webapi_project_1.Interface;
using Webapi_project_1.Model;
using Webapi_project_1.Services;
using Xunit;

namespace Login_Test
{
    public class LoginControllerTest
    {
        private readonly Mock<ILoginService> _mockILoginservice;
        private readonly Mock<ILogger<LoginController>> _mockILogger;
        private readonly Mock<LoginService> _mockLoginservice;

        public LoginControllerTest()
        {
            _mockILoginservice = new Mock<ILoginService>();
            _mockILogger = new Mock<ILogger<LoginController>>();

            _mockLoginservice = new Mock<LoginService>();
        }
       

        [Fact]
        public void Loginget_ReturnLogincollection()
        {//Arrange
            Credentials credentials = new Credentials();
            LoginDetails employees = new LoginDetails();
            credentials.username = "Sanjay";
            credentials.pwd = "kumar";
            var data = new LoginDetails
            {
                id = 77,
                username = "sanjay",
                pwd = "sanjay",
                department = "mech",
                logintype = "admin"
            };

            LoginDetails loginDetails = new LoginDetails();
            employees.id = 77;
            employees.username = "sanjay";
            employees.pwd = "sanjay";
            //Act
            _mockILoginservice.Setup(x => x.GetLoginDetails(credentials)).ReturnsAsync(data);
            LoginController loginController = new LoginController(_mockILoginservice.Object, _mockILogger.Object);

            var post = loginController.Get(credentials);
            //Assert

            post.Should().BeOfType<LoginCollection>();
        }
        [Fact]
        public void Login_return_null_exception()

        {
            //Arrange
            Credentials credentials = new Credentials();
            LoginDetails employees = new LoginDetails();
            credentials.username = "Sanjay";
            credentials.pwd = "kumar";
            var data = new LoginDetails
            {
                id = 77,
                username = "sanjay",
                pwd = "sanjay",
                department = "mech",
                logintype = null
            };

            LoginDetails loginDetails = new LoginDetails();
            employees.id = 77;
            employees.username = "sanjay";
            employees.pwd = "sanjay";
            //Act
            _mockILoginservice.Setup(x => x.GetLoginDetails(credentials)).ReturnsAsync(data);
            LoginController loginController = new LoginController(_mockILoginservice.Object, _mockILogger.Object);

            //Assert

           
           Assert.ThrowsAsync<ArgumentNullException>(() => loginController.Get(credentials));
           



        }
        [Fact]
        public async Task Login_return_null_exception_with_password_and_username_empty()

        {
            //Arrange
            Credentials credentials = new Credentials();
            
         
            //Act
      
            LoginController loginController = new LoginController(_mockILoginservice.Object, _mockILogger.Object);
          //  var post = await loginController.Get(credentials);
            //Assert
           await Assert.ThrowsAsync<ArgumentNullException>(() => loginController.Get(credentials));


        }
        [Fact]
        public async Task Login_without_password()

        {
            //Arrange
            Credentials credentials = new Credentials();
            
            credentials.username = "Sanjay";
           
            //Act
           
            LoginController loginController = new LoginController(_mockILoginservice.Object, _mockILogger.Object);

            //Assert

            await Assert.ThrowsAsync<ArgumentNullException>(() => loginController.Get(credentials));

        }
        [Fact]
        public async Task Login_without_username()

        {
            //Arrange
            Credentials credentials = new Credentials();

            credentials.pwd = "kumar";


            //Act

            LoginController loginController = new LoginController(_mockILoginservice.Object, _mockILogger.Object);

            //Assert

            await Assert.ThrowsAsync<ArgumentNullException>(() => loginController.Get(credentials));

        }
        [Fact]
        public async Task Login_unsucessfull()

        {
            //Arrange
            Credentials credentials = new Credentials();

            credentials.pwd = "kumar";


            //Act

            LoginController loginController = new LoginController(_mockILoginservice.Object, _mockILogger.Object);

            //Assert

            await Assert.ThrowsAsync<ArgumentNullException>(() => loginController.Get(credentials));

        }
    }
    }
