﻿using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Webapi_project_1.Controllers;
using Webapi_project_1.Interface;
using Webapi_project_1.Model;
using Webapi_project_1.Services;
using Xunit;

namespace Login_Test
{
    public class Employee_Test
    {
        private readonly Mock<EmployeeCouchbaseService> _mockService;
        private readonly Mock<IEmployeeCouchbaseService> _mockIService;
        private readonly Mock<ILogger<EmployeeController>> _mockILogger;
        private readonly Mock<ILogger<EmployeeCouchbaseService>> _mockILoggerService;

        public Employee_Test()
        {
            _mockService = new Mock<EmployeeCouchbaseService>();
            _mockIService = new Mock<IEmployeeCouchbaseService>();
            _mockILogger = new Mock<ILogger<EmployeeController>>();
            _mockILoggerService = new Mock<ILogger<EmployeeCouchbaseService>>();

        }
        
        [Fact]
        public async Task Get_returns_employeecollection()
        {
            Paging paging = new Paging();
            paging.start = 0;
            paging.end = 5;
            EmployeeCouchbaseService employeeCouchbaseService = new EmployeeCouchbaseService(_mockILoggerService.Object);

            var Couchbase = await employeeCouchbaseService.Initialize();
            EmployeeCollection employeeCollection = new EmployeeCollection();
            employeeCollection = await employeeCouchbaseService.GetEmployees(Couchbase, paging);
          //  Assert.Equal(employeeCollection, employeeCollection);
            employeeCollection.Should().BeOfType<EmployeeCollection>();

        }
        [Fact]
        public async Task Get_returns_nullException_pagingisempty()
        {
            Paging paging = new Paging();
            EmployeeController employeeController = new EmployeeController(_mockIService.Object,_mockILogger.Object);
           
           
            await Assert.ThrowsAsync<ArgumentNullException>(() => employeeController.Get(paging));


        }
        [Fact]
        public async Task Get_returns_nullException_employeecollection()
        {
            Paging paging = new Paging();
            paging.start = 0;
            paging.end = 5;

            EmployeeCollection employees = new EmployeeCollection();

            EmployeeCouchbaseService employeeCouchbaseService = new EmployeeCouchbaseService(_mockILoggerService.Object);

            var Couchbase = await employeeCouchbaseService.Initialize();


            _mockIService.Setup(x => x.GetEmployees(Couchbase, paging)).ReturnsAsync(employees);
            EmployeeController employeeController = new EmployeeController(_mockIService.Object, _mockILogger.Object);

            await Assert.ThrowsAsync<ArgumentNullException>(() => employeeController.Get(paging));


        }
        [Fact]
        public async Task Get_byId_returns_employee()
        {
            var employee = new Employees
            {
                id = 2,
                name = "sanjay",
                srccs = "photo",
            };
            int id = 2;
            EmployeeCouchbaseService employeeCouchbaseService = new EmployeeCouchbaseService(_mockILoggerService.Object);


            _mockIService.Setup(x => x.GetEmployeById(id)).ReturnsAsync(employee);
            EmployeeController employeeController = new EmployeeController(_mockIService.Object, _mockILogger.Object);
            EmployeeCollection employeeCollection = new EmployeeCollection();

            var emp = await employeeController.Get(id);

           emp.Should().BeOfType<Employees>();


        }
        [Fact]
        public async Task Get_byId_returns_nullException_withoutId()
        {

            int id = 0;

            EmployeeController employeeController = new EmployeeController(_mockIService.Object, _mockILogger.Object);

            await Assert.ThrowsAsync<ArgumentNullException>(() => employeeController.Get(id));


        }
        [Fact]
        public async Task Get_byId_returns_nullException()
        {
            var employee = new Employees
            { };
            int id = 2;
            EmployeeCouchbaseService employeeCouchbaseService = new EmployeeCouchbaseService(_mockILoggerService.Object);


            _mockIService.Setup(x => x.GetEmployeById(id)).ReturnsAsync(employee);
            EmployeeController employeeController = new EmployeeController(_mockIService.Object, _mockILogger.Object);
            EmployeeCollection employeeCollection = new EmployeeCollection();



            await Assert.ThrowsAsync<ArgumentNullException>(() => employeeController.Get(id));


        }
        [Fact]
        public async Task Get_byid_returns_nullException_when_servicereturns_null()
        {
            int id = 2;


            Employees employees = new Employees();

            EmployeeCouchbaseService employeeCouchbaseService = new EmployeeCouchbaseService(_mockILoggerService.Object);

            var Couchbase = await employeeCouchbaseService.Initialize();


            _mockIService.Setup(x => x.GetEmployeById(id)).ReturnsAsync(employees);
            EmployeeController employeeController = new EmployeeController(_mockIService.Object, _mockILogger.Object);

            await Assert.ThrowsAsync<ArgumentNullException>(() => employeeController.Get(id));


        }
        [Fact]
        public async Task post_success()
        {
            Employees employee = new Employees();
            employee.id = 9988;
            employee.name = "sanjay";
            employee.srccs = "photo";
            EmployeeCouchbaseService employeeCouchbaseService = new EmployeeCouchbaseService(_mockILoggerService.Object);


          var emp= await employeeCouchbaseService.PostEmploye(employee);



            // Assert.Null(emp);
            emp.Should().BeOfType<IActionResult>();
        }
        [Fact]
        public async Task post_without_id()
        {
            Employees employee = new Employees();
    
            employee.name = "sanjay";
            employee.srccs = "photo";

            EmployeeController employeeController = new EmployeeController(_mockIService.Object, _mockILogger.Object); 

            await Assert.ThrowsAsync<ArgumentNullException>(() => employeeController.Post(employee));

        }

        
        [Fact]
        public async Task Update_byId_returns_employees()
        {
            var employee = new Employees
            {
                id = 2,
                name = "sanjay",
                srccs = "photo",
            };
            int id = 2;
         


            _mockIService.Setup(x => x.PutEmployeById(id,employee)).ReturnsAsync(employee);
            EmployeeController employeeController = new EmployeeController(_mockIService.Object, _mockILogger.Object);
            EmployeeCollection employeeCollection = new EmployeeCollection();

            var emp = await employeeController.Put(id,employee);

           // Assert.Equal(employee, emp);
            emp.Should().BeOfType<OkResult>();

        }
        [Fact]
        public async Task Update_withoutId_returns_null_exception()
        {
            var employee = new Employees
            {
              
                name = "sanjay",
                srccs = "photo",
            };
            int id = 0;

            EmployeeController employeeController = new EmployeeController(_mockIService.Object, _mockILogger.Object);
           
            await Assert.ThrowsAsync<ArgumentNullException>(() => employeeController.Put(id,employee));

           


        }
        [Fact]
        public async Task Delete_employee_byid_returnnull_exception()
        {

            int id = 0;

            EmployeeController employeeController = new EmployeeController(_mockIService.Object, _mockILogger.Object);

            await Assert.ThrowsAsync<ArgumentNullException>(() => employeeController.Delete(id));


        }
        [Fact]
        public async Task Delete_byId()
        {
            Employees employees = new Employees();
            int id = 2;
            EmployeeCouchbaseService employeeCouchbaseService = new EmployeeCouchbaseService(_mockILoggerService.Object);

            _mockIService.Setup(x => x.DeleteEmployeById(id)).ReturnsAsync(employees);
            EmployeeController employeeController = new EmployeeController(_mockIService.Object, _mockILogger.Object);

            var emp = await employeeController.Delete(id);
            emp.Should().BeOfType<Employees>();
         
           


        }

        [Fact]
        public async Task Post_Login()
        {
            var form = new LoginDetails
            {
                id = 111,
                username = "sanjay",
                pwd = "sanjay",
                department = "mech",
                logintype = "admin"
            };
            EmployeeCouchbaseService employeeCouchbaseService = new EmployeeCouchbaseService(_mockILoggerService.Object);
            var data = await employeeCouchbaseService.PostLogin(form);
          //  Assert.IsType<OkResult>(data);
            Assert.Null(data);

        }



        [Fact]
        public async Task Post_Login_Without_id()
        {
            var form = new LoginDetails
            {

                username = "sanjay",
                pwd = "sanjay",
                department = "mech",
                logintype = "admin"
            };


            EmployeeController employeeController = new EmployeeController(_mockIService.Object, _mockILogger.Object);

            await Assert.ThrowsAsync<ArgumentNullException>(() => employeeController.Postlogin(form));

        }
        [Fact]
        public async Task Post_Login_returnsnull_when_servicereturns_null()
        {
            var form = new LoginDetails
            {
                id = 2,
                username = "sanjay",
                pwd = "sanjay",
                department = "mech",
                logintype = "admin"
            };
            LoginDetails loginDetails = new LoginDetails();

            _mockIService.Setup(x => x.PostLogin(form)).ReturnsAsync(loginDetails);
            EmployeeController employeeController = new EmployeeController(_mockIService.Object, _mockILogger.Object);

            await Assert.ThrowsAsync<ArgumentNullException>(() => employeeController.Postlogin(form));

        }
    }
}
