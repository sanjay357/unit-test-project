﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Webapi_project_1.Model
{
    public class EmployeeCollection
    {
        public List<Employees> employees { get; set;}
        public int employeeCount { get; set; }

    }
}
