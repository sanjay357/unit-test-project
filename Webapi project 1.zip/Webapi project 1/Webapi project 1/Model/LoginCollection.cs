﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Webapi_project_1.Model
{
    public class LoginCollection
    {

        public LoginDetails loginDetails { get; set; }
        public string token { get; set; }

    }
}
