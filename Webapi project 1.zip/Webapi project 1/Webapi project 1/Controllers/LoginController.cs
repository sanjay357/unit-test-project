﻿using Microsoft.AspNet.OData;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Webapi_project_1.Interface;
using Webapi_project_1.Model;

namespace Webapi_project_1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class LoginController : ControllerBase
    {
        private readonly ILoginService _service;
        private readonly ILogger<LoginController> logger;
        

        public LoginController(ILoginService Service, ILogger<LoginController> logger)
        {
            this._service = Service;
            this.logger = logger;
            
        }
        // GET: api/<LoginController>
        [HttpGet]
       [EnableQuery()]
        [AllowAnonymous]
        public async Task<LoginCollection> Get([FromQuery] Credentials credentials)
        {logger.LogInformation("Getting all Login details");
            LoginCollection login = new LoginCollection();
          
            if (credentials.pwd == null && credentials.username==null)
            {
                  throw new ArgumentNullException("username and password");
               // logger.LogInformation("username and password is Empty");
               // return login;
            }
            if (credentials.username == null)
            {
                logger.LogInformation("username is empty");
                throw new ArgumentNullException("username is empty");
            }
            if (credentials.pwd == null)
            {
                logger.LogInformation("password is empty");
               throw new ArgumentNullException("password is empty");
            }
          
            //  var couchClient = await _service.Initialize();
            var loginDetails = await _service.GetLoginDetails(credentials);
            
            if (loginDetails == null)
            {
                logger.LogError("Error in getting Login details");
                return login;
            }
            if(loginDetails.id==0 || loginDetails.logintype == null)
            {

                throw new ArgumentNullException("ID or logintype is empty");
            }

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                   {

                       new Claim(ClaimTypes.Name, loginDetails.id.ToString()),
                       new Claim(ClaimTypes.Role, loginDetails.logintype.ToString()),

                   }),
                Expires = DateTime.UtcNow.AddMinutes(50),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(Encoding.ASCII.GetBytes("1234567890123456")), SecurityAlgorithms.HmacSha256Signature)
            };
            var tokenHandler = new JwtSecurityTokenHandler();
            var securityToken = tokenHandler.CreateToken(tokenDescriptor);
            loginDetails.pwd = null;
            login.loginDetails = loginDetails;



            login.token = tokenHandler.WriteToken(securityToken);
            logger.LogInformation(login.token);
            return login;
        }

        

    }
}
