﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Webapi_project_1.Interface;
using Webapi_project_1.Model;
using Microsoft.AspNet.OData;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Webapi_project_1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize (AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
  
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeCouchbaseService _service;
     
        private readonly ILogger<EmployeeController> logger;

        public EmployeeController(IEmployeeCouchbaseService service,  ILogger<EmployeeController> logger)
        {
            _service = service;
          
            this.logger = logger;
            logger.LogInformation( "NLog injected into EmployeeController");
        }
        // GET: api/<EmployeeController>
        [HttpGet]
     //  [EnableQuery()]
     [Authorize (Roles ="superadmin,user,admin")]
        public async Task<EmployeeCollection> Get([FromQuery] Paging paging  )
        {
           if(paging.end==0& paging.start==0)
            {
                throw new ArgumentNullException("please provide the start number and end number");
            }
            logger.LogInformation("geting  all Employees");
            var couchClient = await _service.Initialize();
            var employees = await _service.GetEmployees(couchClient ,paging);
           
            if (employees == null)
            {
                logger.LogWarning("Can't get Employees");
                throw new ArgumentNullException("Can't get Employees");

            }
          

           return employees;
        }



        // GET api/<EmployeeController>/5
        [HttpGet("{id}")]
        [Authorize (Roles ="superadmin,admin,user")]
        ////[HttpGet("{department}/{id}")]
        public async Task<Employees> Get(int id)
        {
            
          if(id==0)


            {
                throw new ArgumentNullException("Pass the id value");
            }
            var employees = await _service.GetEmployeById( id);
            if (employees.id == 0)
            {
                logger.LogWarning($"Employee With Id- {id} not found");
                logger.LogError("This is an error");
                throw new ArgumentNullException("");
              
            }
            return employees;


        }

        // POST api/<EmployeeController>
        [HttpPost]
        [Authorize(Roles = "superadmin,admin")]
        public async Task<IActionResult> Post([FromBody] Employees value)
        {
            if (value.id == 0)
            {
                throw new ArgumentNullException("There is no id value");
            }
            logger.LogInformation($"Posting this  {value} Employee");
            await _service.PostEmploye( value);

            return Ok();

        } 

        //update
        // PUT api/<EmployeeController>/5
        [HttpPut("{id}")]
        [Authorize (Roles ="superadmin,admin")]
        public async Task<IActionResult> Put(int id, [FromBody] Employees value)
        {
            if (id == 0)

            {
                throw new ArgumentNullException("id is empty");
            }
            logger.LogInformation($"Updating  this Id-{id}");
            Employees employees = new Employees();
            employees= await _service.PutEmployeById( id,value);

            return Ok();
           
        }

        // DELETE api/<EmployeeController>/5
        [HttpDelete("{id}")]
        [Authorize (Roles ="superadmin")]
        public async Task<IActionResult> Delete(int id)
        
        {
            if(id==0)

            {
                throw new ArgumentNullException("id is empty");
            }
            logger.LogInformation($"Deleting this Id-{id}");
            Employees employees = new Employees();
            employees= await _service.DeleteEmployeById( id);

            return Ok();


        }
        // POST api/<LoginController>
        [HttpPost]
        [Authorize(Roles = "superadmin,admin")]
        [Route("LoginPost")]
        public async Task<IActionResult> Postlogin([FromBody] LoginDetails form)
        {
            if(form.id==0)
            {
                throw new ArgumentNullException();
            }
           // var couchClient = await service.Initialize();
            var logindata = await _service.PostLogin(form);
            if (logindata.logintype == null)
            {
                throw new ArgumentNullException();
            }
            else
            {
                logger.LogInformation("Successfully posted");

                return Ok();
            }
           
        }
    }
}
