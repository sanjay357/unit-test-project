import { EmployeeCollection } from './employee-collection';

describe('EmployeeCollection', () => {
  it('should create an instance', () => {
    expect(new EmployeeCollection()).toBeTruthy();
  });
});
