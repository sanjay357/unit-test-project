export class Employeedetails {
    id:number;
    srccs:string;
    name: string;
    age: number;
    location: string;
    address: string;
    phoneNumber: number;
    salary: number;
    skill: string;
    managerName: string;
    email:string;
    
}

