import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Employeedetails } from 'src/app/EmployeesDetail/employeedetails';
import { LoginServiceService } from '../service/login-service.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
  employee: Employeedetails = new Employeedetails();
  submit:string;
  idvalue:number;
  funvalue:boolean=false;




  constructor(private addservice: LoginServiceService) { }

  ngOnInit(): void {
  }

  onSubmit(form: NgForm): void {
    
    if (form.valid ) {
     
      console.log(form.value)
     
      this.addservice.create(form.value).subscribe(m => {
        console.log(m);
     
        form.resetForm();
        this.submit= "Form is submitted"
        if(this.submit== "Form is submitted") { 
          this.funvalue=false;
      } else{
        this.funvalue=false;
      }
        window.confirm("Form is submitted")
        
      })
    }
    else{
      window.confirm("Please fill the required field")
    }
  }
}
