import { Tokenn } from './token';

describe('Token', () => {
  it('should create an instance', () => {
    expect(new Tokenn()).toBeTruthy();
  });
});
