﻿using Couchbase;
using Couchbase.Core.Exceptions;
using Microsoft.Extensions.Logging;
using Polly;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Webapi_project_1.Interface;
using Webapi_project_1.Model;

namespace Webapi_project_1.Services
{
    public class LoginService : ILoginService
    {
        private readonly ILogger<LoginService> logger;

        public LoginService(ILogger<LoginService> logger)
        {
            this.logger = logger;
        }
        public async Task<LoginDetails> GetLoginDetails(Credentials credentials)
        {
            try
            {
                
                   var cluster = await Initialize();
                var queryResult = await cluster.QueryAsync<LoginDetails>("SELECT department,logintype,id,photo,username,pwd FROM LoginDetails ", new Couchbase.Query.QueryOptions());

                List<LoginDetails> empList = new List<LoginDetails>();

                await foreach (var row in queryResult)
                {
                    empList.Add(row);
                }

               
                var employee = empList.Find(x => x.username == credentials.username && x.pwd == credentials.pwd);
                return employee;

            }
            catch (IndexFailureException)
            {
                logger.LogError("Bucket not found");
                throw;
            }
            
        }

    
      

        public async Task<ICluster> Initialize()
        {
            try
            {
                var policy = Policy.Handle<Exception>()
                   .WaitAndRetryAsync(2, count => TimeSpan.FromSeconds(3));
                await policy.ExecuteAsync(async () =>
                {
                             logger.LogInformation("Retrying to connect Couchbase for LoginController...");
                    await Retry();
                    });
                return await Retry();
            }
            catch (AuthenticationFailureException)
            {
                logger.LogError("Authentication error");
                throw ;
            }   
        }
        public async Task<ICluster> Retry()
        {
            var cluster = await Cluster.ConnectAsync("couchbase://localhost", "adm", "sanjay753");
            var bucket = await cluster.BucketAsync("LoginDetails");
            var collection = bucket.DefaultCollection();
            return cluster;
        }
      
    }
}
