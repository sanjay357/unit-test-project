﻿using Couchbase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Webapi_project_1.Model;

namespace Webapi_project_1.Interface
{
    public interface ILoginService
    {
        Task<ICluster> Initialize();
        Task<LoginDetails> GetLoginDetails(Credentials credentials);
     


    }
}
